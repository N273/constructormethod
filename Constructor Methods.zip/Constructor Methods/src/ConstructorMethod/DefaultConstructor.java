package ConstructorMethod;

public class DefaultConstructor {
// create a class with default constructor method

        int age;
        String name;
        // method to Display the value of age and name
        public void displayMessage() {
            System.out.println(age + "" + name);

        }public static void main(String[]args) {
            // creating a object
            DefaultConstructor a = new DefaultConstructor();
            // Creating value for the object
            a.displayMessage();


        }


    }





























